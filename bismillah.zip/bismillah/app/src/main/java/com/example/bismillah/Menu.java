package com.example.bismillah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Menu extends AppCompatActivity {
    public ImageView imap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        imap = findViewById(R.id.map);
        imap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String places = "https://www.google.com/maps/search/bank+sampah+di+yogyakarta/@-7.8153203,110.3078161,12z/data=!3m1!4b1";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(places)));
            }
        });
    }


    public void sampah(View view) {
        Intent intent = new Intent(Menu.this, Jemput.class);
        startActivity(intent);
    }

    public void kategori(View view) {
        Intent intent = new Intent(Menu.this, Kategori.class);
        startActivity(intent);
    }


    public void info(View view) {
        Intent intent = new Intent(Menu.this, Info.class);
        startActivity(intent);
    }
}