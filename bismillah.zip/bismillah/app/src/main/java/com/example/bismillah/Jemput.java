package com.example.bismillah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Jemput extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jemput);
    }

    public void selesai(View view) {
        Intent intent = new Intent(Jemput.this, Finish.class);
        startActivity(intent);
    }

    public void kategori(View view) {
        Intent intent = new Intent(Jemput.this, Kategori.class);
        startActivity(intent);
    }
}